thinKbox 2.3.0 — Linux portable amd64

RUN WITHOUT INSTALLING
    ./thinkbox

OPTIONAL USER INSTALL
    ./INSTALL.sh

UNINSTALL USER INSTALL
    ./UNINSTALL.sh

REQUIREMENTS
- 64-bit Intel/AMD Linux
- graphical web browser
- xdg-utils
- libheif-examples (provides heif-convert for HEIC/HEIF images)

DATA COMPATIBILITY
thinKbox intentionally continues to use:
    Documents/Kishore's Notes

This preserves notes from earlier Kishore's Notes and thinKbox versions.

FEATURE PARITY WITH MAC 1.1.2
- thinKbox branding and left-side title beside numbered navigation
- automatic Q/A and cloze Flashcards
- Spaced Inbox with Again / Soon / Later / Exciting
- Q:/A: interleaved active recall
- Markdown
- Tags / Categories
- full navigation history with maximum five previous spines
- Created / Modified dates
- backlinks and [[internal links]]
- cloze
- images including HEIC/HEIF -> JPEG
- Brain Map
- Search
- external web links
- Publish Website

SELF TEST
    ./thinkbox --self-test
