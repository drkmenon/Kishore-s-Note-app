#!/bin/sh
set -eu
HERE=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
DEST="$HOME/.local/opt/thinkbox"
BIN="$HOME/.local/bin"
APPDIR="$HOME/.local/share/applications"
ICONDIR="$HOME/.local/share/icons/hicolor/512x512/apps"
mkdir -p "$DEST" "$BIN" "$APPDIR" "$ICONDIR"
cp "$HERE/thinkbox" "$DEST/thinkbox"
chmod 755 "$DEST/thinkbox"
cp "$HERE/thinkbox.png" "$ICONDIR/thinkbox.png"
ln -sf "$DEST/thinkbox" "$BIN/thinkbox"
ln -sf "$DEST/thinkbox" "$BIN/kishores-notes"
cat > "$APPDIR/thinkbox.desktop" <<DESKTOP
[Desktop Entry]
Name=thinKbox
Comment=Local-first linked notes, flashcards and Spaced Inbox
Exec=$DEST/thinkbox
Icon=thinkbox
Terminal=false
Type=Application
Categories=Office;Utility;
StartupNotify=true
DESKTOP
chmod 644 "$APPDIR/thinkbox.desktop"
command -v update-desktop-database >/dev/null 2>&1 && update-desktop-database "$APPDIR" >/dev/null 2>&1 || true
echo "thinKbox installed."
echo "Run: $DEST/thinkbox"
echo "Your existing notes remain in Documents/Kishore's Notes."
