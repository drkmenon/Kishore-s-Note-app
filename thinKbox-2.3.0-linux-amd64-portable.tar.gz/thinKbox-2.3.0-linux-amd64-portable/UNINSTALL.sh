#!/bin/sh
set -eu
rm -rf "$HOME/.local/opt/thinkbox"
rm -f "$HOME/.local/bin/thinkbox" "$HOME/.local/bin/kishores-notes"
rm -f "$HOME/.local/share/applications/thinkbox.desktop"
rm -f "$HOME/.local/share/icons/hicolor/512x512/apps/thinkbox.png"
echo "thinKbox application files removed."
echo "Your notes in Documents/Kishore's Notes were NOT deleted."
