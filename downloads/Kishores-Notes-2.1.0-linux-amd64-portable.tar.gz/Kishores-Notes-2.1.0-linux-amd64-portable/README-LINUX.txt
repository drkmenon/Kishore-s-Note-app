KISHORE'S NOTES 2.1.0 — LINUX AMD64
Feature parity release with the Mac 1.0.5 note system.

RUN PORTABLY
  ./kishores-notes

INSTALL FOR YOUR USER ACCOUNT
  ./INSTALL.sh

No sudo is required for the portable installer.

REQUIREMENTS
- A graphical web browser (Chromium/Chrome/Firefox)
- xdg-utils is recommended
- HEIC/HEIF support requires heif-convert from libheif-examples
  Ubuntu/Debian: sudo apt install libheif-examples xdg-utils

NOTES STORAGE
  Documents/Kishore's Notes

WEBSITE EXPORT
Use Publish Website in the app. The generated folder is:
  Documents/Kishore's Notes Website

FEATURES
- Andy-style linked note panes and last-five history
- responsive mobile top-down history
- no accidental horizontal scrolling
- Markdown headings, bold, italic, strike, code, lists, tasks, quotes, rules, tables
- [[internal note links]] and automatic Backlinks
- cloze {{c1::answer}}
- external Markdown links and bare URLs
- JPG/PNG/WEBP/GIF images
- HEIC/HEIF -> JPEG conversion
- automatic Created and Modified timestamps
- Search
- Brain Map
- Publish Website

BUILT-IN TEST
  ./kishores-notes --self-test
