#!/usr/bin/env bash
set -e
rm -rf "$HOME/.local/share/kishores-notes"
rm -f "$HOME/.local/bin/kishores-notes"
rm -f "$HOME/.local/share/applications/kishores-notes.desktop"
echo "Kishore's Notes application removed."
echo "Your Documents/Kishore's Notes folder was left untouched."
