#!/usr/bin/env bash
set -e
HERE="$(cd "$(dirname "$0")" && pwd)"
TARGET="$HOME/.local/share/kishores-notes"
BIN="$HOME/.local/bin"
APPS="$HOME/.local/share/applications"
mkdir -p "$TARGET" "$BIN" "$APPS"
rm -rf "$TARGET"
mkdir -p "$TARGET"
cp "$HERE/kishores-notes" "$TARGET/kishores-notes"
cp "$HERE/kishores-notes.png" "$TARGET/kishores-notes.png"
chmod +x "$TARGET/kishores-notes"
ln -sf "$TARGET/kishores-notes" "$BIN/kishores-notes"
cat > "$APPS/kishores-notes.desktop" <<DESKTOP
[Desktop Entry]
Name=Kishore's Notes
Comment=Linked notes with Markdown, backlinks, cloze, images and Brain Map
Exec=$TARGET/kishores-notes
Icon=$TARGET/kishores-notes.png
Terminal=false
Type=Application
Categories=Office;Utility;
StartupNotify=true
DESKTOP
chmod 0644 "$APPS/kishores-notes.desktop"
command -v update-desktop-database >/dev/null 2>&1 && update-desktop-database "$APPS" >/dev/null 2>&1 || true
printf '\nInstalled Kishore\047s Notes.\n'
if ! command -v heif-convert >/dev/null 2>&1; then
  printf 'Note: HEIC/HEIF images require libheif-examples.\nOn Ubuntu/Debian: sudo apt install libheif-examples\n'
fi
if ! command -v xdg-open >/dev/null 2>&1; then
  printf 'Note: xdg-utils is recommended to open the browser and folders.\n'
fi
printf 'Open it from the Applications menu or run: %s/kishores-notes\n' "$BIN"
