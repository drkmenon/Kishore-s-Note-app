#!/usr/bin/env bash
set -e
HERE="$(cd "$(dirname "$0")" && pwd)"
TARGET="$HOME/.local/share/kishores-notes"
BIN="$HOME/.local/bin"
APPS="$HOME/.local/share/applications"
ICONS="$HOME/.local/share/icons/hicolor/512x512/apps"
mkdir -p "$TARGET" "$BIN" "$APPS" "$ICONS"
cp "$HERE/kishores-notes" "$TARGET/kishores-notes"
cp "$HERE/kishores-notes.png" "$ICONS/kishores-notes.png"
chmod +x "$TARGET/kishores-notes"
ln -sf "$TARGET/kishores-notes" "$BIN/kishores-notes"
cat > "$APPS/kishores-notes.desktop" <<DESKTOP
[Desktop Entry]
Name=Kishore's Notes
Comment=Linked personal notes with backlinks, cloze, images and Brain Map
Exec=$TARGET/kishores-notes
Icon=kishores-notes
Terminal=false
Type=Application
Categories=Office;Utility;
StartupNotify=true
DESKTOP
chmod 644 "$APPS/kishores-notes.desktop"
command -v update-desktop-database >/dev/null 2>&1 && update-desktop-database "$APPS" >/dev/null 2>&1 || true
command -v gtk-update-icon-cache >/dev/null 2>&1 && gtk-update-icon-cache -f "$HOME/.local/share/icons/hicolor" >/dev/null 2>&1 || true

echo "Kishore's Notes installed for this user."
if ! command -v heif-convert >/dev/null 2>&1; then
  echo "NOTE: For HEIC/HEIF images install libheif-examples using your Linux package manager."
fi
if ! command -v chromium >/dev/null 2>&1 && ! command -v chromium-browser >/dev/null 2>&1 && ! command -v google-chrome >/dev/null 2>&1 && ! command -v firefox >/dev/null 2>&1; then
  echo "NOTE: Install a web browser (Chromium/Chrome/Firefox) to open the app window."
fi
echo "Open Kishore's Notes from your Applications menu."
