#!/usr/bin/env bash
set -e
rm -rf "$HOME/.local/share/kishores-notes"
rm -f "$HOME/.local/bin/kishores-notes"
rm -f "$HOME/.local/share/applications/kishores-notes.desktop"
rm -f "$HOME/.local/share/icons/hicolor/512x512/apps/kishores-notes.png"
echo "Application removed. Your Documents/Kishore's Notes data was left untouched."
