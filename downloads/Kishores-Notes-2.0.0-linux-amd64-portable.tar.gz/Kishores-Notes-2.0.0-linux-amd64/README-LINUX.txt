KISHORE'S NOTES 2.0.0 — LINUX AMD64

RECOMMENDED FOR UBUNTU / DEBIAN / LINUX MINT
Use the .deb package instead of this portable archive. The .deb automatically
requires the HEIC conversion helper.

RUN PORTABLE VERSION
1. Extract the .tar.gz archive.
2. Double-click/run: kishores-notes
   or in Terminal: ./kishores-notes

INSTALL INTO YOUR APPLICATIONS MENU
Run: ./INSTALL.sh
No root/sudo is required for this portable installer.

HEIC / HEIF
HEIC conversion uses the standard Linux heif-convert utility. On Debian/Ubuntu:
  sudo apt install libheif-examples
The .deb package declares this dependency automatically.

SELF-TEST
Run:
  ./kishores-notes --self-test
A successful result says:
  SELF-TEST PASS: notes, JPG, real HEIC->JPEG, website export

DATA
Your notes remain in:
  Documents/Kishore's Notes
This is compatible with the existing Kishore's Notes notes.json format.

FEATURES
- New/Edit/Save to real files
- last 5 previous notes as Andy-style spines on larger screens
- top-down collapsed headlines on smaller screens
- no accidental horizontal scrolling
- [[bidirectional links]] and Backlinks
- cloze: {{c1::answer::hint}} (also a1/a2 groups)
- Add Image without browser prompt()
- HEIC/HEIF/JPG/PNG/WEBP/GIF
- Brain Map
- Search
- Notes Folder
- Publish Website -> Netlify-ready folder
